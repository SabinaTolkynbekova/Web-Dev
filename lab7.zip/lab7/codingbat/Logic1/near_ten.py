def near_ten(num):
    return (num % 10) <= 2 or (num % 10 ) >= 8