def count_evens(nums):
    sum = 0
    for i in nums:
        if i % 2 == 0:
            sum += 1
    return sum