def sum2(nums):
    if len(nums) < 2:
        return sum(nums)
    else:
        return nums[0]+nums[1]