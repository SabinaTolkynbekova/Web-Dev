def same_first_last(nums):
    return (len(nums) >= 1 and nums[0] == nums[-1])