def sleep_in(weekday, vacation):
    if vacation == True:
        return True
    else:
        if weekday == True:
            return False
        else:
            return True