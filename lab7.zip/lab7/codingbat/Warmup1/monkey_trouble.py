def monkey_trouble(a_smile, b_smile):
    if a_smile and b_smile is True:
        return True
    elif not a_smile and not b_smile is True:
        return True
    else:
        return False