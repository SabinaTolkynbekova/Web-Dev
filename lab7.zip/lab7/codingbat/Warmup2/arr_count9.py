def array_count9(nums):
    return nums.count(9)