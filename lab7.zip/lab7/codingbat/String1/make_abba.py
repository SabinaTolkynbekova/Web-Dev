def make_abba(a, b):
    return a + b * 2 + a