def make_out_word(out, word):
    return out[0] + out[1] + word + out[2] + out[3]