def hello_name(name):
    s = "Hello " + name + "!"
    return s
    