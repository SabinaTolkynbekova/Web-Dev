def first_two(str):
    if len(str) <= 2:
        return str
    else:
        return str[0] + str[1]