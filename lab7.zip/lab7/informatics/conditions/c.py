x = int(input("x: "))
y = int(input("y: "))
if (x != 1 & y != 1) | (x == 1 & y == 1):
  print("yes")
else:
  print("No")