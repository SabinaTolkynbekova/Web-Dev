def Xor(x, y):
  if(x == True and y == False) or (x == False and y == True):
    return True
  return False