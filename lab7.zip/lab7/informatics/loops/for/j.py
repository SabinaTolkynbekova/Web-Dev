sum_of_hundred = 0

for i in range(1, 100):
  sum_of_hundred += int(input())

print(sum_of_hundred)