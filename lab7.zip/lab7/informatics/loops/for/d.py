x = str(input())
d = str(input())

counter = 0

for i in x:
  if i == d:
    counter += 1

print(counter)