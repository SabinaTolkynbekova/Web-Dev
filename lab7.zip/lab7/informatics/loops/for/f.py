x = str(input())

print(x[::-1])