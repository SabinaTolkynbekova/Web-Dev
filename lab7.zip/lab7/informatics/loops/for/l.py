binary = input()

print(int(binary, 2))